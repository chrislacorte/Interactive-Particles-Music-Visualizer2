import App from './App'
;(() => {
  new App()
})()
